//pin_function_test.h

#define CFGPIN(WORD,PIN,FUNC);
