//delay.h					
#include "types.h"
void delay_ms(u32 dlyMS);
void delay_us(u32 dlyUS);
